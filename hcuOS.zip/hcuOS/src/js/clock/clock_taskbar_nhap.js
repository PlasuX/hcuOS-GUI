setInterval(showTime, 1000);

function showTime() {
    var time = new Date;
    var hour = time.getHours();
    var min = time.getMinutes();
    var sec = time.getSeconds();
    var year = time.getFullYear();
    var date = time.getDate();
    if (date > 3) {
        var date_letter = "th"
    } else switch (date) {
        case 1:
            date_letter = "st";
            break;
        case 2:
            date_letter = "nd";
            break;
        case 3:
            date_letter = "rd"
    }

    var month = new Array(12);
    month[0] = "Jan";
    month[1] = "Feb";
    month[2] = "Mar";
    month[3] = "Apr";
    month[4] = "May";
    month[5] = "Jun";
    month[6] = "Jul";
    month[7] = "Aug";
    month[8] = "Sep";
    month[9] = "Oct";
    month[10] = "Nov";
    month[11] = "Dec";
    var month_num = month[time.getMonth()];

    var weekday = new Array(7);
    weekday[0] = "Sun";
    weekday[1] = "Mon";
    weekday[2] = "Tue";
    weekday[3] = "Wed";
    weekday[4] = "Thu";
    weekday[5] = "Fri";
    weekday[6] = "Sat";
    var day = weekday[time.getDay()];
    //console.log(day + ", " + month_num + " " + date + date_letter + " " + year) //for debugging

    var am_pm = "SA";
    if (hour > 12) {
        hour -= 12;
        am_pm = "CH";
    }
    if (hour == 0) {
        hr = 12;
        am_pm = "AM";
    }
    hour = hour < 10 ? "0" + hour : hour;
    min = min < 10 ? "0" + min : min;
    sec = sec < 10 ? "0" + sec : sec;
    var currentTime = hour + ":" + min + " " + am_pm;
    document.getElementById("clock").innerHTML = currentTime;

    var taskbartime_info = document.getElementById('taskbar_time')
    taskbartime_info.setAttribute('data-title', day + ", " + month_num + " " + date + date_letter + " " + year)
}

showTime();
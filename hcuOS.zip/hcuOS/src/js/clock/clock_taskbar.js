window.onload = function () {
    function showTime() {
        var time = new Date,
            hour = time.getHours(),
            min = time.getMinutes();
        time.getSeconds();
        var year = time.getFullYear(),
            date = time.getDate();
        if (3 < date) {
            var date_letter = "th";
        } else {
            switch (date) {
                case 1:
                    date_letter = "st";
                    break;
                case 2:
                    date_letter = "nd";
                    break;
                case 3:
                    date_letter = "rd";
            }
        }
        var month = Array(12);
        month[0] = "Jan";
        month[1] = "Feb";
        month[2] = "Mar";
        month[3] = "Apr";
        month[4] = "May";
        month[5] = "Jun";
        month[6] = "Jul";
        month[7] = "Aug";
        month[8] = "Sep";
        month[9] = "Oct";
        month[10] = "Nov";
        month[11] = "Dec";
        month = month[time.getMonth()];
        var weekday = Array(7);
        weekday[0] = "Sun";
        weekday[1] = "Mon";
        weekday[2] = "Tue";
        weekday[3] = "Wed";
        weekday[4] = "Thu";
        weekday[5] = "Fri";
        weekday[6] = "Sat";
        time = weekday[time.getDay()];
        weekday = "AM";
        12 < hour && (hour -= 12, weekday = "PM");
        0 == hour && (hr = 12, am_pm = "AM");
        hour = `${hour}:${10 > min ? "0" + min : min} ${weekday}`;
        document.getElementById("clock").innerHTML = hour;
        document.getElementById("taskbar_time").setAttribute("data-title", `${time}, ${month} ${date}${date_letter} ${year}`);
    };
    setInterval(showTime, 1000);
    showTime();

    // Note:
    /* if (hour == 0) {
            hr = 12;
            am_pm = "AM";
        }
        hour = (10 > hour ? "0" + hour : hour) + ":" + (10 > min ? "0" + min : min) + " " + weekday;
    */
}